/*
 * ElementValidationItem.java
 * 
 * Created on Sep 7, 2007, 4:03:01 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.jaspersoft.jasperserver.irplugin.gui.jrxmlvalidator;

import it.businesslogic.ireport.ImageReportElement;
import it.businesslogic.ireport.ReportElement;
import java.io.File;

/**
 *
 * @author gtoffoli
 */
public class ElementValidationItem {

    private File originalFileName = null;
            
    private String proposedExpression = null;
    
    private String resourceName = null;
    
    private String parentFolder = null;
    
    private ReportElement reportElement = null;
    
    public ReportElement getReportElement() {
        return reportElement;
    }

    public void setReportElement(ReportElement reportElement) {
        this.reportElement = reportElement;
    }
    
    public File getOriginalFileName() {
        return originalFileName;
    }

    public void setOriginalFileName(File originalFileName) {
        this.originalFileName = originalFileName;
    }
    
    public String toString()
    {
        return this.getReportElement().toString();
    }

    public String getProposedExpression() {
        return proposedExpression;
    }

    public void setProposedExpression(String proposedExpression) {
        this.proposedExpression = proposedExpression;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public String getParentFolder() {
        return parentFolder;
    }

    public void setParentFolder(String parentFolder) {
        this.parentFolder = parentFolder;
    }
    
}
