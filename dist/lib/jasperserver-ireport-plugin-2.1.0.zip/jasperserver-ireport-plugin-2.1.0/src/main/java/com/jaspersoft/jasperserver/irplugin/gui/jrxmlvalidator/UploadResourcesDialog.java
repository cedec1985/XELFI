/*
 * Copyright (C) 2005 - 2007 JasperSoft Corporation.  All rights reserved.
 * http://www.jaspersoft.com.
 *
 * Unless you have purchased a commercial license agreement from JasperSoft,
 * the following license terms apply:
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 as published by
 * the Free Software Foundation.
 *
 * This program is distributed WITHOUT ANY WARRANTY; and without the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, see http://www.gnu.org/licenses/gpl.txt
 * or write to:
 *
 * Free Software Foundation, Inc.,
 * 59 Temple Place - Suite 330,
 * Boston, MA  USA  02111-1307
 */
package com.jaspersoft.jasperserver.irplugin.gui.jrxmlvalidator;

import com.jaspersoft.jasperserver.api.metadata.xml.domain.impl.ResourceDescriptor;
import com.jaspersoft.jasperserver.irplugin.IRPlugin;
import it.businesslogic.ireport.ImageReportElement;
import it.businesslogic.ireport.SubReportElement;
import it.businesslogic.ireport.gui.MainFrame;
import it.businesslogic.ireport.util.Misc;
import java.awt.Image;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author  gtoffoli
 */
public class UploadResourcesDialog extends javax.swing.JDialog implements Runnable {
    
    private JrxmlValidationDialog validationDialog = null;
    private java.util.List resourceItems = null;
        
    /** Creates new form UploadResourcesDialog */
    public UploadResourcesDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        
        jProgressBar1.setMinimum(0);
        jProgressBar1.setMaximum(100);
        jProgressBar1.setValue(0);
        
        Misc.centerFrame(this);
    }
    
    public void setLabel(String label)
    {
        jLabel.setText( label );
    }
    
    public void setCompletation(int d)
    {
        jProgressBar1.setValue(d);
    }
    
    
    public void startProcessing()
    {
        Thread t = new Thread(this);
        t.start();
    }
    
    public void run()
    {
        jProgressBar1.setValue(0);
        
        jLabel.setText(IRPlugin.getString("uploadResourcesDialog.adaptingJRXML","Adapting JRXML source...") );
        JrxmlValidationDialog vd = getValidationDialog();
        
        jProgressBar1.setValue(5);
        
         try {
            
            for (int i=0; i< resourceItems.size(); ++i)
            {
                jProgressBar1.setValue(15);
                ElementValidationItem evi = (ElementValidationItem)resourceItems.get(i);

                ResourceDescriptor newDescriptor = new ResourceDescriptor();
                newDescriptor.setUriString( evi.getParentFolder() + "/" + evi.getResourceName());
                newDescriptor.setParentFolder( evi.getParentFolder());
                newDescriptor.setName( evi.getResourceName() );
                newDescriptor.setLabel( evi.getResourceName() );
                newDescriptor.setIsNew(true);
                newDescriptor.setHasData(true);
                    
                if (evi instanceof ImageElementValidationItem)
                {
                    ImageElementValidationItem iev = (ImageElementValidationItem)evi;
                    Image img = ((ImageReportElement)iev.getReportElement()).getImg();
                    ((ImageReportElement)iev.getReportElement()).setImageExpression("\"" + iev.getProposedExpression() + "\"");
                   ((ImageReportElement) iev.getReportElement()).setImg( img );
                    jProgressBar1.setValue(20);
                    newDescriptor.setWsType(  ResourceDescriptor.TYPE_IMAGE );
                    //newDescriptor.setParentFolder( (vd.getReportUnit() != null) ? vd.getReportUnit().getDescriptor().getUriString() : "/");
                }
                else if (evi instanceof SubReportElementValidationItem)
                {
                    SubReportElementValidationItem iev = (SubReportElementValidationItem)evi;
                    ((SubReportElement)iev.getReportElement()).setSubreportExpression("\"" + iev.getProposedExpression() + "\"");
                    newDescriptor.setWsType(  ResourceDescriptor.TYPE_JRXML );
                }
                    
                jLabel.setText(
                        IRPlugin.getFormattedString("uploadResourcesDialog.uploadingResource","Uploading {0}",new Object[]{evi.getOriginalFileName().getName()}));
                
                System.out.println("Modifing resource with RU " + vd.getReportUnit());
                System.out.flush();
                vd.getServer().getWSClient().modifyReportUnitResource(
                            (vd.getReportUnit() != null) ? vd.getReportUnit().getDescriptor().getUriString() : null,
                            newDescriptor, evi.getOriginalFileName());
                jProgressBar1.setValue( (int)(100.0/(double)i));
            }
            
            vd.getReport().saveXMLFile();
            IRPlugin.getMainInstance().getRepositoryExplorer().refreshContentNodeObject(vd.getReportUnit());
            
        } catch (Exception ex)
        {
                final Exception ex2 = ex;
                ex.printStackTrace();
                try {
                    SwingUtilities.invokeAndWait( new Runnable(){

                    public void run()
                    {
                        setVisible(false);
                        dispose();

                        JOptionPane.showMessageDialog(MainFrame.getMainInstance(), 
                                IRPlugin.getFormattedString("uploadResourcesDialog.uploadingResourceError","An error occurred during resource upload:\n{0}",new Object[]{ex2.getMessage()}),
                                "Error",
                        JOptionPane.ERROR_MESSAGE);
                    }
                });

                } catch (Exception ex3){
                }
            
            ex.printStackTrace();
        }
        finally {
          
            try {
            SwingUtilities.invokeAndWait( new Runnable(){
            public void run()
                {
                    setVisible(false);
                    dispose();
                }
            });
            } catch (Exception ex3){
                }
        }
        getValidationDialog().elaborationFinished(true);
    }
    
    public void setVisible(boolean b)
    {
        if (b) startProcessing();
        super.setVisible(b);
    }
    
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc=" Generated Code ">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        jLabel = new javax.swing.JLabel();
        jProgressBar1 = new javax.swing.JProgressBar();

        getContentPane().setLayout(new java.awt.GridBagLayout());

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        jLabel.setText("Uploading resources...");
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(8, 8, 4, 8);
        getContentPane().add(jLabel, gridBagConstraints);

        jProgressBar1.setPreferredSize(new java.awt.Dimension(250, 18));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(0, 8, 8, 8);
        getContentPane().add(jProgressBar1, gridBagConstraints);

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UploadResourcesDialog(new javax.swing.JFrame(), true).setVisible(true);
            }
        });
    }

    public JrxmlValidationDialog getValidationDialog() {
        return validationDialog;
    }

    public void setValidationDialog(JrxmlValidationDialog validationDialog) {
        this.validationDialog = validationDialog;
    }

    public java.util.List getResourceItems() {
        return resourceItems;
    }

    public void setResourceItems(java.util.List resourceItems) {
        this.resourceItems = resourceItems;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel;
    private javax.swing.JProgressBar jProgressBar1;
    // End of variables declaration//GEN-END:variables
    
}
